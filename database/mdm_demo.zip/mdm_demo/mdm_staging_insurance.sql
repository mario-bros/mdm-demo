-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 28, 2020 at 02:17 PM
-- Server version: 10.1.35-MariaDB
-- PHP Version: 7.2.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mdm_staging_insurance`
--

-- --------------------------------------------------------

--
-- Table structure for table `mdm_staging_customer_profile`
--

CREATE TABLE `mdm_staging_customer_profile` (
  `u_id` varchar(250) NOT NULL,
  `unit` varchar(50) DEFAULT 'INSU',
  `customer_id` varchar(50) DEFAULT NULL,
  `full_name` varchar(250) DEFAULT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `middle_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `surname` varchar(50) DEFAULT NULL,
  `nickname` varchar(50) DEFAULT NULL,
  `gender` varchar(50) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `pob` varchar(50) DEFAULT NULL,
  `address` varchar(250) DEFAULT NULL,
  `nomor` char(10) DEFAULT NULL,
  `blok` char(10) DEFAULT NULL,
  `rt` char(10) DEFAULT NULL,
  `rw` char(10) DEFAULT NULL,
  `kelurahan` varchar(50) DEFAULT NULL,
  `kecamatan` varchar(50) DEFAULT NULL,
  `kota` varchar(50) DEFAULT NULL,
  `propinsi` varchar(50) DEFAULT NULL,
  `kodepos` char(10) DEFAULT NULL,
  `longitude` varchar(50) DEFAULT NULL,
  `latitude` varchar(50) DEFAULT NULL,
  `status_tempat_tinggal` varchar(50) DEFAULT NULL,
  `type_tempat_tinggal` varchar(50) DEFAULT NULL,
  `category_tempat_tinggal` varchar(50) DEFAULT NULL,
  `email1` varchar(100) DEFAULT NULL,
  `email2` varchar(100) DEFAULT NULL,
  `telepon_rumah` varchar(50) DEFAULT NULL,
  `telepon_kantor` varchar(50) DEFAULT NULL,
  `fax` varchar(50) DEFAULT NULL,
  `mobile_phone1` varchar(50) DEFAULT NULL,
  `mobile_phone2` varchar(50) DEFAULT NULL,
  `ktp` varchar(50) DEFAULT NULL,
  `suku` varchar(50) DEFAULT NULL,
  `kewarganegaraan` varchar(50) DEFAULT NULL,
  `negara` varchar(50) DEFAULT NULL,
  `religion` varchar(50) DEFAULT NULL,
  `pendidikan` varchar(50) DEFAULT NULL,
  `profesi` varchar(50) DEFAULT NULL,
  `golongan_darah` char(10) DEFAULT NULL,
  `status_kawin` varchar(50) DEFAULT NULL,
  `mortalitas` varchar(50) DEFAULT NULL,
  `category_user` varchar(50) DEFAULT NULL,
  `status_keaktifan` varchar(50) DEFAULT NULL,
  `status_pengkinian_data` varchar(50) DEFAULT NULL,
  `product` varchar(2000) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `flag_process` smallint(6) DEFAULT NULL,
  `process_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `category` varchar(50) DEFAULT NULL,
  `id_type` varchar(50) DEFAULT NULL,
  `home_address_2` varchar(250) DEFAULT NULL,
  `kode_pos` varchar(10) DEFAULT NULL,
  `home_country` varchar(50) DEFAULT NULL,
  `jabatan` varchar(100) DEFAULT NULL,
  `annual_income` varchar(50) DEFAULT NULL,
  `source_of_addl_income` varchar(50) DEFAULT NULL,
  `additional_income` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mdm_staging_customer_profile`
--

INSERT INTO `mdm_staging_customer_profile` (`u_id`, `unit`, `customer_id`, `full_name`, `first_name`, `middle_name`, `last_name`, `surname`, `nickname`, `gender`, `dob`, `pob`, `address`, `nomor`, `blok`, `rt`, `rw`, `kelurahan`, `kecamatan`, `kota`, `propinsi`, `kodepos`, `longitude`, `latitude`, `status_tempat_tinggal`, `type_tempat_tinggal`, `category_tempat_tinggal`, `email1`, `email2`, `telepon_rumah`, `telepon_kantor`, `fax`, `mobile_phone1`, `mobile_phone2`, `ktp`, `suku`, `kewarganegaraan`, `negara`, `religion`, `pendidikan`, `profesi`, `golongan_darah`, `status_kawin`, `mortalitas`, `category_user`, `status_keaktifan`, `status_pengkinian_data`, `product`, `created_at`, `updated_at`, `flag_process`, `process_at`, `category`, `id_type`, `home_address_2`, `kode_pos`, `home_country`, `jabatan`, `annual_income`, `source_of_addl_income`, `additional_income`) VALUES
('0000002A-0F96-4E03-903D-9FC0D37E0280', 'INSU', '1500038175', 'SARYOTO .', 'SARYOTO .', NULL, NULL, NULL, NULL, 'L', '1982-07-25', 'CIREBON', 'JL. AMBAR BINANGUN NO. 469 RT. 11 (FOTOCOPY MERRY)', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'random@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-08-23 02:10:16', NULL, NULL, '2020-06-22 10:18:07', NULL, 'K', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('00000348-C9F8-42AB-87E0-7AA031C35680', 'INSU', '730358217', 'FTV', 'FTV', NULL, NULL, NULL, NULL, 'L', '1982-07-25', 'CIREBON', 'JL. AMBAR BINANGUN NO. 469 RT. 11 (FOTOCOPY MERRY)', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'random@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-08-23 02:10:16', NULL, NULL, '2020-06-22 10:18:07', NULL, 'K', NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2020_08_23_074211_create_mdm_staging_insurance_mdm_staging_customer_profile', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `mdm_staging_customer_profile`
--
ALTER TABLE `mdm_staging_customer_profile`
  ADD PRIMARY KEY (`u_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
